/******************************************************************
** 
** CS-305 Project 2
** SslServerApplicationTests.java
** 
** David Vega
** Southern New Hampshire University
** CS-305-T3311 Software Security
** Dr. Vivian Lyon
** February 19, 2023
**
******************************************************************/

package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
